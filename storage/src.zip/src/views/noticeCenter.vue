<template>
  <div class="header-container">
    <div class="module-title">
      <h1>订单中心</h1>
    </div>
    <div class="content-container">
        
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less"></style>
